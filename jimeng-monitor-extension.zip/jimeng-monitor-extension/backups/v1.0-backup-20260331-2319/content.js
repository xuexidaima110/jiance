/**
 * 即梦视频任务监控器 - Content Script v2
 * 修复：支持 /ai-tool/generate 页面，主动轮询API，扩大任务识别
 */

(() => {
  'use strict';

  // ============ 状态 ============
  const intercepted = {
    tasks: {},       // taskId -> {id, status, prompt, ...}
    csrfToken: '',
    sessionId: '',
    deviceId: '',
    userId: '',
  };

  const ACTIVE_CACHE_TTL_MS = 30000;
  const FINISHED_CACHE_TTL_MS = 120000;

  function isExtensionContextValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function safeGetRuntimeUrl(path) {
    if (!isExtensionContextValid()) return null;
    try {
      return chrome.runtime.getURL(path);
    } catch {
      return null;
    }
  }

  async function safeSendRuntimeMessage(message) {
    if (!isExtensionContextValid()) return null;
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      const messageText = String(error?.message || error || '');
      if (!messageText.includes('Extension context invalidated')) {
        console.debug('[即梦监控] sendMessage 失败:', error);
      }
      return null;
    }
  }

  function isRunningStatus(status) {
    return ['running', 'pending', 'processing', 'in_queue', 'submitted'].includes(status);
  }

  function isFinishedStatus(status) {
    return ['success', 'failed'].includes(status);
  }

  function isVideoTask(task) {
    if (!task) return false;
    if (task.kind === 'video') return true;
    if (task.kind === 'image') return false;
    const hint = `${task._url || ''} ${task.prompt || ''}`.toLowerCase();       
    if (hint.includes('video') || hint.includes('motion')) return true;
    if (hint.includes('image') || hint.includes('photo') || hint.includes('picture')) return false;
    return false;
  }  function isDomVideoCard(element, text, html) {
    if (!element) return false;
    if (element.querySelector('video')) return true;
    if (element.querySelector('[class*="play"],[class*="preview-video"],[class*="video"]')) return true;
    if (text.includes('视频') || text.includes('秒')) return true;
    if ((html || '').toLowerCase().includes('<video')) return true;
    return false;
  }

  function pruneTaskCache() {
    const now = Date.now();
    for (const [taskId, task] of Object.entries(intercepted.tasks)) {
      if (!isVideoTask(task)) {
        delete intercepted.tasks[taskId];
        continue;
      }

      const lastSeenAt = task._lastSeenAt || 0;
      const ttl = isRunningStatus(task.status) ? ACTIVE_CACHE_TTL_MS : FINISHED_CACHE_TTL_MS;
      if (lastSeenAt && now - lastSeenAt > ttl) {
        delete intercepted.tasks[taskId];
      }
    }
  }

  function getVisibleTasks() {
    pruneTaskCache();
    return Object.values(intercepted.tasks).filter(isVideoTask);
  }

  function getRunningVideoTasks() {
    return getVisibleTasks().filter(task => isRunningStatus(task.status));
  }

  // 即梦已知的任务查询API列表（通过抓包整理）
  // 插件会轮流尝试，直到有效的为止
  const KNOWN_TASK_APIS = [
    '/mweb/v1/query_draft_list?workspace_id=0&count=20&offset=0&filter_type=1',
    '/mweb/v1/get_draft_list?count=20&offset=0',
    '/mweb/v1/query_draft_history?count=20&offset=0',
    '/mweb/v1/aigc_draft_list?count=20&offset=0',
    '/mweb/v1/video_draft_list?count=20',
    '/mweb/v1/works/list?page=1&size=20',
    '/api/v1/task/list?page=1&size=20',
  ];

  let activeApiPath = ''; // 记录有效的API路径

  // ============ 注入拦截脚本（在页面上下文中运行）============
  function injectInterceptor() {
    const scriptUrl = safeGetRuntimeUrl('interceptor.js');
    if (!scriptUrl) return;
    const script = document.createElement('script');
    script.src = scriptUrl;
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  }

  injectInterceptor();

  // ============ 监听来自 interceptor.js 的消息 ============
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.__source !== 'jimeng_interceptor') return;

    if (data.type === 'TASK_DATA') {
      // 从网络请求中捕获到的任务数据
      mergeTaskData(data.tasks || []);
    }
    if (data.type === 'AUTH_DATA') {
      // 捕获到认证信息
      if (data.csrfToken) intercepted.csrfToken = data.csrfToken;
      if (data.sessionId) intercepted.sessionId = data.sessionId;
      if (data.userId) intercepted.userId = data.userId;
      if (data.deviceId) intercepted.deviceId = data.deviceId;
    }
    if (data.type === 'SUBMIT_RESULT') {
      // 提交任务的结果
      window._jimengSubmitResolvers && window._jimengSubmitResolvers[data.reqId]?.(data.result);
    }
  });

  // 状态优先级：数字越高越可信，低优先级不能覆盖高优先级
  const STATUS_PRIORITY = {
    'unknown': 0,
    'pending': 1,
    'in_queue': 2,
    'submitted': 2,
    'processing': 3,
    'running': 3,
    'success': 10,
    'failed': 10,
  };
  function statusPriority(s) { return STATUS_PRIORITY[s] ?? 1; }

  function mergeTaskData(tasks) {
    const now = Date.now();
    for (const t of tasks) {
      if (!t.id || !isVideoTask(t)) continue;
      const prev = intercepted.tasks[t.id];
      if (!prev) {
        intercepted.tasks[t.id] = { ...t, _lastSeenAt: now };
      } else {
        // 只有新状态优先级 >= 旧状态优先级时才更新状态
        // 防止 unknown / pending 覆盖已知的 processing 状态
        const newPrio = statusPriority(t.status);
        const oldPrio = statusPriority(prev.status);
        if (newPrio >= oldPrio) {
          intercepted.tasks[t.id] = { ...prev, ...t, _lastSeenAt: now };
        } else {
          // 保留旧状态，但合并其他字段（如prompt）
          intercepted.tasks[t.id] = { ...prev, ...t, status: prev.status, _lastSeenAt: now };
        }
      }
    }
    // 上报给 background（同步活动任务）—— 扩大进行中状态的识别范围
    const runningTasks = getVisibleTasks().filter(t => {
      const s = t.status;
      return s === 'running' || s === 'pending' || s === 'processing' || s === 'in_queue' || s === 'submitted';
    });
    safeSendRuntimeMessage({ type: 'SYNC_ACTIVE_FROM_PAGE', tasks: runningTasks });
  }

  // ============ 主动轮询：在页面上下文中调用即梦API ============
  async function fetchTasksFromApi() {
    // 先用已知有效路径
    const tryPaths = activeApiPath
      ? [activeApiPath, ...KNOWN_TASK_APIS.filter(p => p !== activeApiPath)]
      : KNOWN_TASK_APIS;

    for (const path of tryPaths) {
      try {
        const resp = await fetch(path, {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
          }
        });
        if (!resp.ok) continue;
        const json = await resp.json();
        // 检查是否有任务数据（不报错且有data字段）
        if (json && (json.data || json.list || json.items || json.works)) {
          // 触发interceptor解析（通过让拦截器处理）
          window.postMessage({
            __source: 'jimeng_content',
            type: 'PARSE_RESPONSE',
            url: path,
            data: json,
          }, '*');
          if (!activeApiPath) {
            activeApiPath = path;
            console.log('[即梦监控] 发现有效API路径:', path);
          }
          return json;
        }
      } catch (e) {}
    }
    return null;
  }

  // ============ 响应 background 的消息 ============
  if (isExtensionContextValid()) chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleBgMessage(message).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  });

  async function simulateDomSubmit(params) {
    return new Promise(async (resolve) => {
      try {
        const sleep = ms => new Promise(r => setTimeout(r, ms));

        const isVisibleElement = (el) => {
          if (!el || !(el instanceof Element)) return false;
          const style = window.getComputedStyle(el);
          const rect = el.getBoundingClientRect();
          return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
        };

        const findClickableElement = (el) => {
          if (!el) return null;
          return el.closest('button, [role="button"], [role="tab"], [role="radio"], [role="option"], label, .arco-select-view, .arco-radio, .arco-tabs-tab, [class*="select"], [class*="tab"], [class*="option"], [class*="trigger"], [class*="radio"]') || el;
        };

        const getPromptTextarea = () => {
          return document.querySelector('textarea.arco-input') ||
                 document.querySelector('textarea[placeholder*="提示词"]') ||
                 document.querySelector('textarea.prompt-input') ||
                 document.querySelector('textarea');
        };

        const firePress = async (el) => {
          if (!el || !isVisibleElement(el)) return false;
          try {
            el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
          } catch (_) {}

          const rect = el.getBoundingClientRect();
          const eventOpts = {
            bubbles: true,
            cancelable: true,
            composed: true,
            view: window,
            clientX: rect.left + Math.max(2, rect.width / 2),
            clientY: rect.top + Math.max(2, rect.height / 2)
          };

          try {
            if (typeof PointerEvent === 'function') {
              el.dispatchEvent(new PointerEvent('pointerdown', eventOpts));
            }
            el.dispatchEvent(new MouseEvent('mousedown', eventOpts));
            if (typeof PointerEvent === 'function') {
              el.dispatchEvent(new PointerEvent('pointerup', eventOpts));
            }
            el.dispatchEvent(new MouseEvent('mouseup', eventOpts));
            el.dispatchEvent(new MouseEvent('click', eventOpts));
            el.click();
            await sleep(150);
            return true;
          } catch (error) {
            console.log('[即梦监控] 点击元素失败:', error);
            return false;
          }
        };

        const collectElementsByText = (text) => {
          if (!text) return [];
          const elements = Array.from(document.querySelectorAll('button, div, span, label, li, p')).filter(el => {
            if (!isVisibleElement(el)) return false;
            const normalized = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
            return normalized === text;
          });

          if (elements.length === 0) {
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
            while (walker.nextNode()) {
              const value = (walker.currentNode.nodeValue || '').replace(/\s+/g, ' ').trim();
              if (value === text && walker.currentNode.parentElement && isVisibleElement(walker.currentNode.parentElement)) {
                elements.push(walker.currentNode.parentElement);
              }
            }
          }

          return elements;
        };

        const setTextareaValue = async (value) => {
          const textarea = getPromptTextarea();
          if (!textarea) return false;
          const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          nativeInputValueSetter.call(textarea, value);
          textarea.dispatchEvent(new Event('input', { bubbles: true }));
          textarea.dispatchEvent(new Event('change', { bubbles: true }));
          await sleep(200);
          return true;
        };

        const clearExistingImages = async () => {
          let cleared = false;
          const emptyTransfer = new DataTransfer();
          const imageInputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(input => !input.accept || input.accept.includes('image'));
          for (const input of imageInputs) {
            try {
              input.files = emptyTransfer.files;
              input.dispatchEvent(new Event('change', { bubbles: true }));
              input.dispatchEvent(new Event('input', { bubbles: true }));
              cleared = true;
            } catch (_) {}
          }

          const removeSelectors = [
            'button[title*="删除"]',
            'button[title*="移除"]',
            'button[title*="清空"]',
            'button[aria-label*="删除"]',
            'button[aria-label*="移除"]',
            'button[aria-label*="清空"]',
            '[class*="remove"]',
            '[class*="delete"]',
            '[class*="clear"]'
          ];

          const seen = new Set();
          for (const selector of removeSelectors) {
            const candidates = Array.from(document.querySelectorAll(selector)).filter(el => {
              if (!isVisibleElement(el)) return false;
              if (seen.has(el)) return false;
              const text = (el.innerText || el.textContent || '').trim();
              const title = `${el.getAttribute('title') || ''} ${el.getAttribute('aria-label') || ''} ${text}`;
              return /删除|移除|清空|重置/.test(title) || text === '×' || text === '✕';
            });

            for (const candidate of candidates.slice(0, 3)) {
              seen.add(candidate);
              if (await firePress(findClickableElement(candidate))) {
                cleared = true;
                await sleep(150);
              }
            }
          }

          if (cleared) {
            await sleep(400);
          }
          return cleared;
        };

        // Helpers
        const tryClickText = async (text) => {
          if (!text) return false;
          const elements = collectElementsByText(text).reverse();
          for (const rawEl of elements) {
            const el = findClickableElement(rawEl);
            if (await firePress(el)) {
              await sleep(350);
              return true;
            }
          }
          return false;
        };

        const tryOpenField = async (labelText) => {
          const labels = collectElementsByText(labelText).reverse();
          for (const labelEl of labels) {
            let container = labelEl;
            for (let depth = 0; depth < 4 && container; depth += 1) {
              const clickable = container.querySelector?.('input, button, [role="button"], [role="tab"], .arco-select-view, [class*="select"], [class*="trigger"], [class*="dropdown"], [class*="tab"]');
              if (clickable && await firePress(clickable)) {
                await sleep(300);
                return true;
              }
              container = container.parentElement;
            }
            const fallback = findClickableElement(labelEl);
            if (await firePress(fallback)) {
              await sleep(300);
              return true;
            }
          }
          return false;
        };

        const ensureReferenceMode = async (targetMode) => {
          if (!targetMode) return false;
          const knownModes = ['全能参考', '颈部参考', '服装参考'];
          
          if (await tryClickText(targetMode)) {
            return true;
          }

          await tryOpenField('参考模式');
          if (await tryClickText(targetMode)) {
            return true;
          }

          for (const mode of knownModes) {
            if(mode !== targetMode && await tryClickText(mode)) {
              await sleep(250);
              if (await tryClickText(targetMode)) {
                return true;
              }
            }
          }

          return false;
        };

        const task = params;

        // ===== waitForDropdown: 等待某个下拉选项出现 =====
        const waitForDropdown = async (timeoutMs = 1500) => {
          const end = Date.now() + timeoutMs;
          while (Date.now() < end) {
            const dropdown = document.querySelector(
              '.arco-select-dropdown, .arco-trigger-popup, [class*="dropdown-menu"], [class*="select-dropdown"], [class*="option-list"]'
            );
            if (dropdown && isVisibleElement(dropdown)) return dropdown;
            await sleep(80);
          }
          return null;
        };

        // ===== selectOption: 打开下拉后等待出现再选值 =====
        const selectOption = async (triggerText, optionText) => {
          if (!optionText) return false;
          // 先尝试直接点文字（如果已经是 tab/radio 样式）
          if (await tryClickText(optionText)) return true;
          // 尝试打开下拉
          if (!await tryOpenField(triggerText)) return false;
          await waitForDropdown(1500);
          if (await tryClickText(optionText)) return true;
          return false;
        };

        // ===== 刷新页面状态：关闭可能已开启的下拉/弹窗 =====
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        await sleep(300);

        // ===== 步骤 1：创作模式（生成模式）下拉 =====
        const targetGenMode = task.genMode || '视频生成';
        await selectOption('创作模式', targetGenMode);
        await sleep(400);

        // ===== 步骤 2：模型 =====
        const targetModel = task.model || task.modelName || '';
        if (targetModel) {
          await selectOption('模型', targetModel);
          await sleep(400);
        }

        // ===== 步骤 3：参考模式 =====
        const targetRefMode = task.refMode || (task.settings && task.settings['\u53c2\u8003\u6a21\u5f0f']) || '';
        if (targetRefMode) {
          await ensureReferenceMode(targetRefMode);
          await sleep(400);
        }

        // ===== 步骤 4：视频比例 =====
        const targetRatio = task.ratio || (task.settings && task.settings['\u89c6\u9891\u6bd4\u4f8b']) || '';
        if (targetRatio) {
          await selectOption('\u89c6\u9891\u6bd4\u4f8b', targetRatio);
          await sleep(400);
        }

        // ===== 步骤 5：视频时长 =====
        const targetDuration = task.duration || (task.settings && task.settings['\u89c6\u9891\u65f6\u957f']) || '';
        if (targetDuration) {
          await selectOption('\u89c6\u9891\u65f6\u957f', targetDuration);
          await sleep(400);
        }

        // ===== 步骤 6a：填写提示词（先填文字，再上传图片）=====
        // 先填提示词，确保 textarea 存在
        if (task.prompt) {
          const filled = await setTextareaValue(task.prompt);
          if (!filled) {
            // 如果第一次没找到 textarea，等一下再试
            await sleep(500);
            await setTextareaValue(task.prompt);
          }
          await sleep(300);
        }

        // ===== 步骤 6b：上传图片 =====
        if (task.imageData) {
          const imageInputs = Array.from(document.querySelectorAll('input[type="file"]'))
            .filter(inp => !inp.accept || inp.accept.includes('image'));
          if (imageInputs.length > 0) {
            try {
              const byteStr = atob(task.imageData.split(',')[1] || task.imageData);
              const arr = new Uint8Array(byteStr.length);
              for (let i = 0; i < byteStr.length; i++) arr[i] = byteStr.charCodeAt(i);
              const mimeMatch = task.imageData.match(/data:(.*?);/);
              const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
              const file = new File([arr], task.imageName || 'image.jpg', { type: mime });
              const dt = new DataTransfer();
              dt.items.add(file);
              imageInputs[0].files = dt.files;
              imageInputs[0].dispatchEvent(new Event('change', { bubbles: true }));
              imageInputs[0].dispatchEvent(new Event('input', { bubbles: true }));
              // 等待图片上传后页面稳定
              await sleep(1200);
            } catch (imgErr) {
              console.warn('[\u5373\u68a6\u76d1\u63a7] \u56fe\u7247\u6ce8\u5165\u5931\u8d25:', imgErr);
            }
          }
          // 图片上传后 textarea 可能被重新渲染，重新填一次提示词
          if (task.prompt) {
            await setTextareaValue(task.prompt);
            await sleep(300);
          }
        }

        // ===== 步骤 7：点击发送箭头（提交）=====
        let submitted = false;

        // 找提示框容器
        const promptContainerSelectors = [
          '.prompt-input-wrap',
          '[class*="prompt-input"]',
          '[class*="promptInput"]',
          '[class*="input-wrap"]',
        ];
        let promptContainer = null;
        for (const sel of promptContainerSelectors) {
          promptContainer = document.querySelector(sel);
          if (promptContainer) break;
        }

        // 在容器内找发送按钮
        const sendBtnSelectors = [
          '[class*="send-btn"]',
          '[class*="sendBtn"]',
          '[class*="submit-btn"]',
          'button[class*="send"]',
          'button[class*="submit"]',
          '[class*="send"][role="button"]',
        ];
        const searchRoot = promptContainer || document;
        for (const sel of sendBtnSelectors) {
          const btn = searchRoot.querySelector(sel);
          if (btn && isVisibleElement(btn)) {
            submitted = await firePress(btn);
            if (submitted) break;
          }
        }

        // 未找到：取容器内最后一个可见 SVG 的可点击父节点
        if (!submitted && promptContainer) {
          const svgs = Array.from(promptContainer.querySelectorAll('svg'));
          for (let i = svgs.length - 1; i >= 0; i--) {
            const parent = svgs[i].closest('button, [role="button"]') || svgs[i].parentElement;
            if (parent && isVisibleElement(parent)) {
              submitted = await firePress(parent);
              if (submitted) break;
            }
          }
        }

        // 最终降级：点「生成」文字
        if (!submitted) {
          submitted = await tryClickText('\u751f\u6210');
        }

        if (submitted) {
          resolve({ ok: true });
        } else {
          resolve({ error: '\u672a\u627e\u5230\u63d0\u4ea4\u6309\u94ae' });
        }

      } catch (e) {
        resolve({ error: 'DOM\u64cd\u4f5c\u5f02\u5e38: ' + e.message });
      }
    });
  }

  async function handleBgMessage(message) {
    switch (message.type) {

      case 'GET_TASK_LIST': {
        // 先主动拉一次API (带超时保护，防止阻塞)
        const fetchPromise = fetchTasksFromApi();
        const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
        await Promise.race([fetchPromise, timeoutPromise]);
        
        const domTasks = parseTasksFromDOM();
        if (domTasks.length > 0) mergeTaskData(domTasks);
        // 返回当前捕获到的所有任务
        const tasks = getVisibleTasks();
        return {
          allTasks: tasks,
          activeTasksSnapshot: getRunningVideoTasks(),
          apiAvailable: true,
        };
      }

      case 'SUBMIT_TASK': {
        const timeoutPromise = new Promise(resolve => setTimeout(() => resolve({ error: 'DOM模拟点击超时' }), 25000));
        const domPromise = simulateDomSubmit(message.params);
        const domResult = await Promise.race([domPromise, timeoutPromise]);
        
        if (domResult && !domResult.error) {
           return domResult;
        }

        console.log('[即梦监控] DOM模拟点击未生效或超时，降级使用原生API提交:', domResult?.error);

        // 让 interceptor 在页面上下文中提交任务（绕过CORS）
        const reqId = 'req_' + Date.now();
        const result = await new Promise((resolve) => {
          if (!window._jimengSubmitResolvers) window._jimengSubmitResolvers = {};
          window._jimengSubmitResolvers[reqId] = resolve;
          setTimeout(() => {
            if (window._jimengSubmitResolvers[reqId]) {
              resolve({ error: 'timeout' });
              delete window._jimengSubmitResolvers[reqId];
            }
          }, 30000);
          window.postMessage({
            __source: 'jimeng_content',
            type: 'SUBMIT_TASK',
            params: message.params,
            reqId,
          }, '*');
        });
        return result;
      }

      case 'GET_AUTH': {
        return intercepted;
      }

      default:
        return { error: 'unknown' };
    }
  }

  // ============ DOM 观察：解析页面上的任务卡片 ============
  function parseTasksFromDOM() {
    const tasks = [];

    // 即梦视频生成页面的实际DOM结构（根据 /ai-tool/generate 页面）
    const selectors = [
      '[data-task-id]',
      '[data-id]',
      '[class*="task-item"]',
      '[class*="generate-item"]',
      '[class*="video-task"]',
      '[class*="creation-item"]',
      '[class*="history-item"]',
      '[class*="record-item"]',
      '[class*="work-item"]',
      '[class*="draft-item"]',
      '[class*="card-wrap"]',
      '[class*="GenerateItem"]',
      '[class*="TaskCard"]',
      '[class*="VideoCard"]',
    ];

    const seen = new Set();
    for (const sel of selectors) {
      let els;
      try { els = document.querySelectorAll(sel); } catch { continue; }
      for (const el of els) {
        const taskId =
          el.dataset.taskId ||
          el.dataset.id ||
          el.dataset.generateId ||
          el.getAttribute('data-task-id') ||
          el.getAttribute('data-id') ||
          el.getAttribute('data-generate-id');
        if (!taskId || seen.has(taskId)) continue;
        seen.add(taskId);

        // 推测状态（中文文本 + CSS类名）
        let status = 'unknown';
        const text = el.textContent || '';
        const html = el.innerHTML || '';

        if (
          el.querySelector('[class*="loading"],[class*="progress"],[class*="generating"],[class*="spinning"],[class*="pending"],[class*="running"]') ||
          text.includes('生成中') || text.includes('处理中') || text.includes('排队') ||
          text.includes('等待') || text.includes('提交中') || html.includes('loading')
        ) {
          status = 'processing';
        } else if (
          el.querySelector('[class*="fail"],[class*="error"],[class*="failed"]') ||
          text.includes('失败') || text.includes('错误') || text.includes('超时')
        ) {
          status = 'failed';
        } else if (
          el.querySelector('[class*="success"],[class*="done"],[class*="complete"],[class*="finish"]') ||
          text.includes('完成') || text.includes('成功') || text.includes('已生成')
        ) {
          status = 'success';
        }

        const kind = isDomVideoCard(el, text, html) ? 'video' : 'unknown';

        if (status !== 'unknown') {
          tasks.push({ id: taskId, status, source: 'dom', kind });
        }
      }
    }

    return tasks;
  }

  // 定期扫描DOM + 主动拉API
  let pollCount = 0;
  setInterval(async () => {
    const domTasks = parseTasksFromDOM();
    if (domTasks.length > 0) mergeTaskData(domTasks);

    // 每隔3次（约9秒）主动调一次API
    pollCount++;
    if (pollCount % 3 === 0) {
      await fetchTasksFromApi();
    }
  }, 3000);

  // ============ 监听即梦的自定义事件（如果有）============
  document.addEventListener('jimeng:task:update', (e) => {
    if (e.detail) mergeTaskData([e.detail]);
  });

  console.log('[即梦监控] Content script 已注入');
})();
