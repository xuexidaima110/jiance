/**
 * 即梦视频任务监控器 - Content Script v2
 * 修复：支持 /ai-tool/generate 页面，主动轮询API，扩大任务识别
 */

(() => {
  'use strict';

  // ============ 状态 ============
  const intercepted = {
    tasks: {},       // taskId -> {id, status, prompt, ...}
    csrfToken: '',
    sessionId: '',
    deviceId: '',
    userId: '',
  };

  const ACTIVE_CACHE_TTL_MS = 30000;
  const FINISHED_CACHE_TTL_MS = 120000;

  function isExtensionContextValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function safeGetRuntimeUrl(path) {
    if (!isExtensionContextValid()) return null;
    try {
      return chrome.runtime.getURL(path);
    } catch {
      return null;
    }
  }

  async function safeSendRuntimeMessage(message) {
    if (!isExtensionContextValid()) return null;
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      const messageText = String(error?.message || error || '');
      if (!messageText.includes('Extension context invalidated')) {
        console.debug('[即梦监控] sendMessage 失败:', error);
      }
      return null;
    }
  }

  function isRunningStatus(status) {
    return ['running', 'pending', 'processing', 'in_queue', 'submitted'].includes(status);
  }

  function isFinishedStatus(status) {
    return ['success', 'failed'].includes(status);
  }

  function isVideoTask(task) {
    if (!task) return false;
    if (task.kind === 'video') return true;
    if (task.kind === 'image') return false;
    const hint = `${task._url || ''} ${task.prompt || ''}`.toLowerCase();       
    if (hint.includes('video') || hint.includes('motion')) return true;
    if (hint.includes('image') || hint.includes('photo') || hint.includes('picture')) return false;
    return false;
  }  function isDomVideoCard(element, text, html) {
    if (!element) return false;
    if (element.querySelector('video')) return true;
    if (element.querySelector('[class*="play"],[class*="preview-video"],[class*="video"]')) return true;
    if (text.includes('视频') || text.includes('秒')) return true;
    if ((html || '').toLowerCase().includes('<video')) return true;
    return false;
  }

  function pruneTaskCache() {
    const now = Date.now();
    for (const [taskId, task] of Object.entries(intercepted.tasks)) {
      if (!isVideoTask(task)) {
        delete intercepted.tasks[taskId];
        continue;
      }

      const lastSeenAt = task._lastSeenAt || 0;
      const ttl = isRunningStatus(task.status) ? ACTIVE_CACHE_TTL_MS : FINISHED_CACHE_TTL_MS;
      if (lastSeenAt && now - lastSeenAt > ttl) {
        delete intercepted.tasks[taskId];
      }
    }
  }

  function getVisibleTasks() {
    pruneTaskCache();
    return Object.values(intercepted.tasks).filter(isVideoTask);
  }

  function getRunningVideoTasks() {
    return getVisibleTasks().filter(task => isRunningStatus(task.status));
  }

  // 即梦已知的任务查询API列表（通过抓包整理）
  // 插件会轮流尝试，直到有效的为止
  const KNOWN_TASK_APIS = [
    '/mweb/v1/query_draft_list?workspace_id=0&count=20&offset=0&filter_type=1',
    '/mweb/v1/get_draft_list?count=20&offset=0',
    '/mweb/v1/query_draft_history?count=20&offset=0',
    '/mweb/v1/aigc_draft_list?count=20&offset=0',
    '/mweb/v1/video_draft_list?count=20',
    '/mweb/v1/works/list?page=1&size=20',
    '/api/v1/task/list?page=1&size=20',
  ];

  let activeApiPath = ''; // 记录有效的API路径

  // ============ 注入拦截脚本（在页面上下文中运行）============
  function injectInterceptor() {
    const scriptUrl = safeGetRuntimeUrl('interceptor.js');
    if (!scriptUrl) return;
    const script = document.createElement('script');
    script.src = scriptUrl;
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  }

  injectInterceptor();

  // ============ 监听来自 interceptor.js 的消息 ============
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.__source !== 'jimeng_interceptor') return;

    if (data.type === 'TASK_DATA') {
      // 从网络请求中捕获到的任务数据
      mergeTaskData(data.tasks || []);
    }
    if (data.type === 'AUTH_DATA') {
      // 捕获到认证信息
      if (data.csrfToken) intercepted.csrfToken = data.csrfToken;
      if (data.sessionId) intercepted.sessionId = data.sessionId;
      if (data.userId) intercepted.userId = data.userId;
      if (data.deviceId) intercepted.deviceId = data.deviceId;
    }
    if (data.type === 'SUBMIT_RESULT') {
      // 提交任务的结果
      window._jimengSubmitResolvers && window._jimengSubmitResolvers[data.reqId]?.(data.result);
    }
  });

  // 状态优先级：数字越高越可信，低优先级不能覆盖高优先级
  const STATUS_PRIORITY = {
    'unknown': 0,
    'pending': 1,
    'in_queue': 2,
    'submitted': 2,
    'processing': 3,
    'running': 3,
    'success': 10,
    'failed': 10,
  };
  function statusPriority(s) { return STATUS_PRIORITY[s] ?? 1; }

  function mergeTaskData(tasks) {
    const now = Date.now();
    for (const t of tasks) {
      if (!t.id || !isVideoTask(t)) continue;
      const prev = intercepted.tasks[t.id];
      if (!prev) {
        intercepted.tasks[t.id] = { ...t, _lastSeenAt: now };
      } else {
        // 只有新状态优先级 >= 旧状态优先级时才更新状态
        // 防止 unknown / pending 覆盖已知的 processing 状态
        const newPrio = statusPriority(t.status);
        const oldPrio = statusPriority(prev.status);
        if (newPrio >= oldPrio) {
          intercepted.tasks[t.id] = { ...prev, ...t, _lastSeenAt: now };
        } else {
          // 保留旧状态，但合并其他字段（如prompt）
          intercepted.tasks[t.id] = { ...prev, ...t, status: prev.status, _lastSeenAt: now };
        }
      }
    }
    // 上报给 background（同步活动任务）—— 扩大进行中状态的识别范围
    const runningTasks = getVisibleTasks().filter(t => {
      const s = t.status;
      return s === 'running' || s === 'pending' || s === 'processing' || s === 'in_queue' || s === 'submitted';
    });
    safeSendRuntimeMessage({ type: 'SYNC_ACTIVE_FROM_PAGE', tasks: runningTasks });
  }

  // ============ 主动轮询：在页面上下文中调用即梦API ============
  async function fetchTasksFromApi() {
    // 先用已知有效路径
    const tryPaths = activeApiPath
      ? [activeApiPath, ...KNOWN_TASK_APIS.filter(p => p !== activeApiPath)]
      : KNOWN_TASK_APIS;

    for (const path of tryPaths) {
      try {
        const resp = await fetch(path, {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
          }
        });
        if (!resp.ok) continue;
        const json = await resp.json();
        // 检查是否有任务数据（不报错且有data字段）
        if (json && (json.data || json.list || json.items || json.works)) {
          // 触发interceptor解析（通过让拦截器处理）
          window.postMessage({
            __source: 'jimeng_content',
            type: 'PARSE_RESPONSE',
            url: path,
            data: json,
          }, '*');
          if (!activeApiPath) {
            activeApiPath = path;
            console.log('[即梦监控] 发现有效API路径:', path);
          }
          return json;
        }
      } catch (e) {}
    }
    return null;
  }

  // ============ 响应 background 的消息 ============
  if (isExtensionContextValid()) chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleBgMessage(message).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  });

  async function simulateDomSubmit(params) {
    return new Promise(async (resolve) => {
      try {
        const task = params;
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const normText = (txt) => String(txt || '').replace(/\s+/g, '').trim();
        const textLike = (actual, expected) => {
          const a = normText(actual);
          const e = normText(expected);
          if (!a || !e) return false;
          return a === e || a.includes(e) || e.includes(a);
        };

        const getCandidateDocs = () => {
          const docs = [document];
          const frames = Array.from(document.querySelectorAll('iframe'));
          for (const frame of frames) {
            try {
              const fd = frame.contentDocument;
              if (fd && !docs.includes(fd)) docs.push(fd);
            } catch {}
          }
          return docs;
        };

        const getWorkDoc = () => {
          const docs = getCandidateDocs();
          let best = document;
          let bestScore = -1;
          for (const d of docs) {
            try {
              const score =
                (d.querySelectorAll('textarea').length * 3) +
                (d.querySelectorAll('.arco-select-view, [class*="select-view"], [role="combobox"]').length * 2) +
                (d.querySelectorAll('input[type="file"]').length);
              if (score > bestScore) {
                best = d;
                bestScore = score;
              }
            } catch {}
          }
          return best;
        };

        const workDoc = getWorkDoc();

        // ---- isVisible: 不使用 scrollIntoView （避免页面滑动） ----
        const isVis = (el) => {
          if (!el || !(el instanceof Element)) return false;
          const s = window.getComputedStyle(el);
          const r = el.getBoundingClientRect();
          return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0'
            && r.width > 0 && r.height > 0;
        };

        // ---- click: 模拟点击，不滚动页面 ----
        const click = async (el) => {
          if (!el || !isVis(el)) return false;
          try {
            const r = el.getBoundingClientRect();
            const cx = r.left + r.width / 2;
            const cy = r.top + r.height / 2;
            const opts = { bubbles: true, cancelable: true, composed: true, view: window, clientX: cx, clientY: cy };
            if (typeof PointerEvent === 'function') {
              el.dispatchEvent(new PointerEvent('pointerdown', opts));
              el.dispatchEvent(new PointerEvent('pointerup', opts));
            }
            el.dispatchEvent(new MouseEvent('mousedown', opts));
            el.dispatchEvent(new MouseEvent('mouseup', opts));
            el.dispatchEvent(new MouseEvent('click', opts));
            el.click();
            await sleep(120);
            return true;
          } catch { return false; }
        };

        // ---- 入口区域：左侧工具栏容器（模型、参考模式、比例、时长等均在其中） ----
        const getToolbar = () =>
          workDoc.querySelector('[class*="left-panel"], [class*="sidebar"], [class*="tool-bar"], [class*="toolbar"], [class*="control-panel"], [class*="params"], [class*="setting"], [class*="config"]') || workDoc.body;

        // ---- 在指定父容器内找包含该文字的元素 ----
        const findByText = (text, root) => {
          root = root || workDoc.body;
          const keys = Array.isArray(text) ? text : [text];
          const all = Array.from(root.querySelectorAll('button, div, span, label, li, p, [role]'));
          return all.find(el => {
            if (!isVis(el)) return false;
            const t = (el.innerText || el.textContent || '');
            return keys.some(k => textLike(t, k));
          }) || null;
        };

        // ---- 在工具栏内找到某标签附近的可点击控件 ----
        const FIELD_ALIASES = {
          '创作模式': ['创作模式', '模式', '生成模式'],
          '模型': ['模型', 'model'],
          '参考模式': ['参考模式', '参考', '参考强度'],
          '视频比例': ['视频比例', '画幅', '比例'],
          '视频时长': ['视频时长', '时长', '片长']
        };

        const findControl = (labelText, root) => {
          root = root || getToolbar();
          const aliases = FIELD_ALIASES[labelText] || [labelText];
          const labelEl = findByText(aliases, root) || findByText(aliases, workDoc.body);
          if (!labelEl) return null;
          // 在局部范围内找可点击元素
          let container = labelEl.parentElement;
          for (let i = 0; i < 4 && container; i++, container = container.parentElement) {
            const btns = Array.from(container.querySelectorAll(
              '.arco-select-view, [class*="select-view"], [class*="trigger"], button, [role="button"], [role="combobox"]'
            )).filter(el => isVis(el) && el !== labelEl);
            if (btns.length > 0) return btns[0];
          }
          const fallbackButtons = Array.from((root || workDoc.body).querySelectorAll('.arco-select-view, [class*="select-view"], [role="combobox"]')).filter(isVis);
          return fallbackButtons[0] || findByText(aliases, root); // fallback: 点标签本身
        };

        // ---- 等待下拉列表出现 ----
        const waitDropdown = async (ms = 1200) => {
          const t = Date.now() + ms;
          while (Date.now() < t) {
            const d = workDoc.querySelector(
              '.arco-select-dropdown, .arco-trigger-popup, [class*="dropdown"][style*="display: block"], [class*="dropdown"][style*="visibility: visible"], [class*="option-list"]'
            );
            if (d && isVis(d)) return d;
            const d2 = document.querySelector('.arco-select-dropdown, .arco-trigger-popup, [class*="dropdown"], [class*="option-list"]');
            if (d2 && isVis(d2)) return d2;
            await sleep(80);
          }
          return null;
        };

        // ---- 在下拉列表里点击某个选项 ----
        const pickOption = async (optionText) => {
          const dd = await waitDropdown(1200);
          const root = dd || workDoc.body;
          const items = Array.from(root.querySelectorAll(
            'li, [role="option"], [class*="option-item"], [class*="select-option"], [class*="dropdown-item"]'
          ));
          const target = items.find(el => {
            if (!isVis(el)) return false;
            const t = (el.innerText || el.textContent || '');
            return textLike(t, optionText);
          });
          if (target) { await click(target); await sleep(300); return true; }
          return false;
        };

        // ---- selectField: 点开某字段的下拉并选娀 ----
        const selectField = async (labelText, optionText) => {
          if (!optionText) return true;
          const ctrl = findControl(labelText);
          if (!ctrl) { console.warn('[\u5373\u68a6\u76d1\u63a7] \u672a\u627e\u5230\u63a7件:', labelText); return false; }
          await click(ctrl);
          await sleep(200);
          const ok = await pickOption(optionText);
          if (!ok) {
            // 点失败，尝试关闭下拉再开
            workDoc.body.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            await sleep(200);
            await click(ctrl);
            await sleep(200);
            return await pickOption(optionText);
          }
          return ok;
        };

        // ---- 填写 textarea（兼容 React） ----
        const fillTextarea = async (text) => {
          const ta = workDoc.querySelector('textarea.arco-input, textarea[placeholder], textarea') ;
          if (!ta) return false;
          // 先 focus
          ta.focus();
          await sleep(80);
          // React native setter hack
          const prev = ta.value;
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
          if (setter) {
            setter.call(ta, text);
          } else {
            ta.value = text;
          }
          const tracker = ta._valueTracker;
          if (tracker && typeof tracker.setValue === 'function') {
            tracker.setValue(prev);
          }
          if (typeof InputEvent === 'function') {
            ta.dispatchEvent(new InputEvent('input', {
              bubbles: true,
              composed: true,
              data: text,
              inputType: 'insertText'
            }));
          } else {
            ta.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
          }
          ta.dispatchEvent(new Event('change', { bubbles: true }));
          ta.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a' }));
          ta.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
          await sleep(200);
          // 验证是否写入
          return (ta.value || '').includes(text.slice(0, 10));
        };

        const selectCreateMode = async (optionText) => {
          if (!optionText) return true;
          const toolbar = getToolbar();
          const tabCandidates = Array.from(toolbar.querySelectorAll('.arco-tabs-tab, [role="tab"], button, div'))
            .filter(el => isVis(el));
          const tab = tabCandidates.find(el => {
            const t = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
            return t === optionText || t.startsWith(optionText);
          });
          if (tab) {
            const ok = await click(tab);
            if (ok) {
              await sleep(300);
              return true;
            }
          }
          return await selectField('创作模式', optionText);
        };

        // ============================================================
        // 正式流程开始
        // ============================================================

        // 步骤 0：关闭当前可能开着的下拉/弹窗（Escape 即可）
        try { window.scrollTo(0, 0); } catch {}
        workDoc.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
        await sleep(400);

        // 步骤 1：创作模式
        const targetGenMode = task.genMode || '视频生成';
        console.log('[即梦] step1 genMode:', targetGenMode);
        await selectCreateMode(targetGenMode);
        await sleep(500);

        // 步骤 2：模型
        const targetModel = task.model || task.modelName || '';
        if (targetModel) {
          console.log('[即梦] step2 model:', targetModel);
          await selectField('模型', targetModel);
          await sleep(500);
        }

        // 步骤 3：参考模式
        const targetRefMode = task.refMode || '';
        if (targetRefMode) {
          console.log('[即梦] step3 refMode:', targetRefMode);
          await selectField('参考模式', targetRefMode);
          await sleep(500);
        }

        // 步骤 4：视频比例
        const targetRatio = task.ratio || '';
        if (targetRatio) {
          console.log('[即梦] step4 ratio:', targetRatio);
          await selectField('视频比例', targetRatio);
          await sleep(500);
        }

        // 步骤 5：视频时长
        const targetDuration = task.duration || '';
        if (targetDuration) {
          console.log('[即梦] step5 duration:', targetDuration);
          await selectField('视频时长', targetDuration);
          await sleep(500);
        }

        // 步骤 6a：填写提示词
        if (task.prompt) {
          console.log('[即梦] step6a prompt:', task.prompt.slice(0, 30));
          let ok = await fillTextarea(task.prompt);
          if (!ok) { await sleep(500); ok = await fillTextarea(task.prompt); }
          await sleep(300);
        }

        // 步骤 6b：上传图片
        if (task.imageData) {
          console.log('[即梦] step6b image:', task.imageName);
          const inputs = Array.from(workDoc.querySelectorAll('input[type="file"]'))
            .filter(inp => !inp.accept || inp.accept.includes('image'));
          if (inputs.length > 0) {
            try {
              const b64 = task.imageData.split(',')[1] || task.imageData;
              const bin = atob(b64);
              const arr = new Uint8Array(bin.length);
              for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
              const mm = task.imageData.match(/data:(.*?);/);
              const mime = mm ? mm[1] : 'image/jpeg';
              const file = new File([arr], task.imageName || 'image.jpg', { type: mime });
              const dt = new DataTransfer();
              dt.items.add(file);
              inputs[0].files = dt.files;
              inputs[0].dispatchEvent(new Event('change', { bubbles: true }));
              inputs[0].dispatchEvent(new Event('input', { bubbles: true }));
              await sleep(1000);
            } catch (e2) { console.warn('[即梦] 图片失败:', e2); }
          }
          // 图片上传后页面可能重渲染，重新填提示词
          if (task.prompt) {
            await fillTextarea(task.prompt);
            await sleep(300);
          }
        }

        // 步骤 7：点击提交按钮
        console.log('[即梦] step7 submit');
        let submitted = false;

        // 找 textarea 局部容器，在其中找发送按钮
        const ta = workDoc.querySelector('textarea.arco-input, textarea[placeholder], textarea');
        const promptWrap = ta
          ? (ta.closest('[class*="prompt"], [class*="input-box"], [class*="input-wrap"], [class*="editor"]') || ta.parentElement?.parentElement)
          : null;

        if (promptWrap) {
          // 先在 promptWrap 中找明确的 send / submit 按钮
          const sendBtn = promptWrap.querySelector(
            '[class*="send"], [class*="submit"], button[type="submit"], [aria-label*="发送"], [aria-label*="生成"], [title*="发送"], [title*="生成"]'
          );
          if (sendBtn && isVis(sendBtn) && !sendBtn.disabled) submitted = await click(sendBtn);

          // 再尝试 SVG 箭头按钮（通常是容器右下角）
          if (!submitted) {
            const allBtns = Array.from(promptWrap.querySelectorAll('button, [role="button"]')).filter(isVis);
            // 取最后一个可见按钮（通常就是发送箭头）
            const clickableBtn = allBtns.reverse().find(btn => !btn.disabled);
            if (clickableBtn) submitted = await click(clickableBtn);
          }
        }

        // 全局降级
        if (!submitted) {
          const globalBtn = workDoc.querySelector('[class*="generate-btn"], [class*="create-btn"], [class*="submit"], [aria-label*="提交"], [aria-label*="生成"]');
          if (globalBtn && isVis(globalBtn) && !globalBtn.disabled) submitted = await click(globalBtn);
        }

        if (!submitted) {
          const endAt = Date.now() + 2500;
          while (Date.now() < endAt && !submitted) {
            const retryBtn = workDoc.querySelector('[class*="send"], [class*="submit"], button[type="submit"], [class*="generate-btn"], [class*="create-btn"], [aria-label*="提交"], [aria-label*="生成"]');
            if (retryBtn && isVis(retryBtn) && !retryBtn.disabled) {
              submitted = await click(retryBtn);
              if (submitted) break;
            }
            await sleep(120);
          }
        }

        console.log('[即梦] submitted:', submitted);
        if (submitted) {
          resolve({ ok: true });
        } else {
          resolve({ error: '未找到提交按钮' });
        }

      } catch (e) {
        resolve({ error: 'DOM操作异常: ' + e.message });
      }
    });
  }

  async function handleBgMessage(message) {
    switch (message.type) {

      case 'GET_TASK_LIST': {
        // 先主动拉一次API (带超时保护，防止阻塞)
        const fetchPromise = fetchTasksFromApi();
        const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
        await Promise.race([fetchPromise, timeoutPromise]);
        
        const domTasks = parseTasksFromDOM();
        if (domTasks.length > 0) mergeTaskData(domTasks);
        // 返回当前捕获到的所有任务
        const tasks = getVisibleTasks();
        return {
          allTasks: tasks,
          activeTasksSnapshot: getRunningVideoTasks(),
          apiAvailable: true,
        };
      }

      case 'SUBMIT_TASK': {
        const timeoutPromise = new Promise(resolve => setTimeout(() => resolve({ error: 'DOM模拟点击超时' }), 25000));
        const domPromise = simulateDomSubmit(message.params);
        const domResult = await Promise.race([domPromise, timeoutPromise]);
        
        if (domResult && !domResult.error) {
           return domResult;
        }

        console.log('[即梦监控] DOM模拟点击未生效或超时，降级使用原生API提交:', domResult?.error);

        // 让 interceptor 在页面上下文中提交任务（绕过CORS）
        const reqId = 'req_' + Date.now();
        const result = await new Promise((resolve) => {
          if (!window._jimengSubmitResolvers) window._jimengSubmitResolvers = {};
          window._jimengSubmitResolvers[reqId] = resolve;
          setTimeout(() => {
            if (window._jimengSubmitResolvers[reqId]) {
              resolve({ error: 'timeout' });
              delete window._jimengSubmitResolvers[reqId];
            }
          }, 30000);
          window.postMessage({
            __source: 'jimeng_content',
            type: 'SUBMIT_TASK',
            params: message.params,
            reqId,
          }, '*');
        });
        return result;
      }

      case 'GET_AUTH': {
        return intercepted;
      }

      default:
        return { error: 'unknown' };
    }
  }

  // ============ DOM 观察：解析页面上的任务卡片 ============
  function parseTasksFromDOM() {
    const tasks = [];

    // 即梦视频生成页面的实际DOM结构（根据 /ai-tool/generate 页面）
    const selectors = [
      '[data-task-id]',
      '[data-id]',
      '[class*="task-item"]',
      '[class*="generate-item"]',
      '[class*="video-task"]',
      '[class*="creation-item"]',
      '[class*="history-item"]',
      '[class*="record-item"]',
      '[class*="work-item"]',
      '[class*="draft-item"]',
      '[class*="card-wrap"]',
      '[class*="GenerateItem"]',
      '[class*="TaskCard"]',
      '[class*="VideoCard"]',
    ];

    const seen = new Set();
    for (const sel of selectors) {
      let els;
      try { els = document.querySelectorAll(sel); } catch { continue; }
      for (const el of els) {
        const taskId =
          el.dataset.taskId ||
          el.dataset.id ||
          el.dataset.generateId ||
          el.getAttribute('data-task-id') ||
          el.getAttribute('data-id') ||
          el.getAttribute('data-generate-id');
        if (!taskId || seen.has(taskId)) continue;
        seen.add(taskId);

        // 推测状态（中文文本 + CSS类名）
        let status = 'unknown';
        const text = el.textContent || '';
        const html = el.innerHTML || '';

        if (
          el.querySelector('[class*="loading"],[class*="progress"],[class*="generating"],[class*="spinning"],[class*="pending"],[class*="running"]') ||
          text.includes('生成中') || text.includes('处理中') || text.includes('排队') ||
          text.includes('等待') || text.includes('提交中') || html.includes('loading')
        ) {
          status = 'processing';
        } else if (
          el.querySelector('[class*="fail"],[class*="error"],[class*="failed"]') ||
          text.includes('失败') || text.includes('错误') || text.includes('超时')
        ) {
          status = 'failed';
        } else if (
          el.querySelector('[class*="success"],[class*="done"],[class*="complete"],[class*="finish"]') ||
          text.includes('完成') || text.includes('成功') || text.includes('已生成')
        ) {
          status = 'success';
        }

        const kind = isDomVideoCard(el, text, html) ? 'video' : 'unknown';

        if (status !== 'unknown') {
          tasks.push({ id: taskId, status, source: 'dom', kind });
        }
      }
    }

    return tasks;
  }

  // 定期扫描DOM + 主动拉API
  let pollCount = 0;
  setInterval(async () => {
    const domTasks = parseTasksFromDOM();
    if (domTasks.length > 0) mergeTaskData(domTasks);

    // 每隔3次（约9秒）主动调一次API
    pollCount++;
    if (pollCount % 3 === 0) {
      await fetchTasksFromApi();
    }
  }, 3000);

  // ============ 监听即梦的自定义事件（如果有）============
  document.addEventListener('jimeng:task:update', (e) => {
    if (e.detail) mergeTaskData([e.detail]);
  });

  console.log('[即梦监控] Content script 已注入');
})();
