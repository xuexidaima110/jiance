/**
 * 即梦视频任务监控器 - Content Script v2
 * 修复：支持 /ai-tool/generate 页面，主动轮询API，扩大任务识别
 */

(() => {
  'use strict';

  // ============ 状态 ============
  const intercepted = {
    tasks: {},       // taskId -> {id, status, prompt, ...}
    csrfToken: '',
    sessionId: '',
    deviceId: '',
    userId: '',
  };

  const ACTIVE_CACHE_TTL_MS = 30000;
  const FINISHED_CACHE_TTL_MS = 120000;

  function isExtensionContextValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function safeGetRuntimeUrl(path) {
    if (!isExtensionContextValid()) return null;
    try {
      return chrome.runtime.getURL(path);
    } catch {
      return null;
    }
  }

  async function safeSendRuntimeMessage(message) {
    if (!isExtensionContextValid()) return null;
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (error) {
      const messageText = String(error?.message || error || '');
      if (!messageText.includes('Extension context invalidated')) {
        console.debug('[即梦监控] sendMessage 失败:', error);
      }
      return null;
    }
  }

  function isRunningStatus(status) {
    return ['running', 'pending', 'processing', 'in_queue', 'submitted'].includes(status);
  }

  function isFinishedStatus(status) {
    return ['success', 'failed'].includes(status);
  }

  function isVideoTask(task) {
    if (!task) return false;
    if (task.kind === 'video') return true;
    if (task.kind === 'image') return false;
    const hint = `${task._url || ''} ${task.prompt || ''}`.toLowerCase();       
    if (hint.includes('video') || hint.includes('motion')) return true;
    if (hint.includes('image') || hint.includes('photo') || hint.includes('picture')) return false;
    return false;
  }  function isDomVideoCard(element, text, html) {
    if (!element) return false;
    if (element.querySelector('video')) return true;
    if (element.querySelector('[class*="play"],[class*="preview-video"],[class*="video"]')) return true;
    if (text.includes('视频') || text.includes('秒')) return true;
    if ((html || '').toLowerCase().includes('<video')) return true;
    return false;
  }

  function pruneTaskCache() {
    const now = Date.now();
    for (const [taskId, task] of Object.entries(intercepted.tasks)) {
      if (!isVideoTask(task)) {
        delete intercepted.tasks[taskId];
        continue;
      }

      const lastSeenAt = task._lastSeenAt || 0;
      const ttl = isRunningStatus(task.status) ? ACTIVE_CACHE_TTL_MS : FINISHED_CACHE_TTL_MS;
      if (lastSeenAt && now - lastSeenAt > ttl) {
        delete intercepted.tasks[taskId];
      }
    }
  }

  function getVisibleTasks() {
    pruneTaskCache();
    return Object.values(intercepted.tasks).filter(isVideoTask);
  }

  function getRunningVideoTasks() {
    return getVisibleTasks().filter(task => isRunningStatus(task.status));
  }

  // 即梦已知的任务查询API列表（通过抓包整理）
  // 插件会轮流尝试，直到有效的为止
  const KNOWN_TASK_APIS = [
    '/mweb/v1/query_draft_list?workspace_id=0&count=20&offset=0&filter_type=1',
    '/mweb/v1/get_draft_list?count=20&offset=0',
    '/mweb/v1/query_draft_history?count=20&offset=0',
    '/mweb/v1/aigc_draft_list?count=20&offset=0',
    '/mweb/v1/video_draft_list?count=20',
    '/mweb/v1/works/list?page=1&size=20',
    '/api/v1/task/list?page=1&size=20',
  ];

  let activeApiPath = ''; // 记录有效的API路径

  // ============ 注入拦截脚本（在页面上下文中运行）============
  function injectInterceptor() {
    const scriptUrl = safeGetRuntimeUrl('interceptor.js');
    if (!scriptUrl) return;
    const script = document.createElement('script');
    script.src = scriptUrl;
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  }

  injectInterceptor();

  // ============ 监听来自 interceptor.js 的消息 ============
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.__source !== 'jimeng_interceptor') return;

    if (data.type === 'TASK_DATA') {
      // 从网络请求中捕获到的任务数据
      mergeTaskData(data.tasks || []);
    }
    if (data.type === 'AUTH_DATA') {
      // 捕获到认证信息
      if (data.csrfToken) intercepted.csrfToken = data.csrfToken;
      if (data.sessionId) intercepted.sessionId = data.sessionId;
      if (data.userId) intercepted.userId = data.userId;
      if (data.deviceId) intercepted.deviceId = data.deviceId;
    }
    if (data.type === 'SUBMIT_RESULT') {
      // 提交任务的结果
      window._jimengSubmitResolvers && window._jimengSubmitResolvers[data.reqId]?.(data.result);
    }
  });

  // 状态优先级：数字越高越可信，低优先级不能覆盖高优先级
  const STATUS_PRIORITY = {
    'unknown': 0,
    'pending': 1,
    'in_queue': 2,
    'submitted': 2,
    'processing': 3,
    'running': 3,
    'success': 10,
    'failed': 10,
  };
  function statusPriority(s) { return STATUS_PRIORITY[s] ?? 1; }

  function mergeTaskData(tasks) {
    const now = Date.now();
    for (const t of tasks) {
      if (!t.id || !isVideoTask(t)) continue;
      const prev = intercepted.tasks[t.id];
      if (!prev) {
        intercepted.tasks[t.id] = { ...t, _lastSeenAt: now };
      } else {
        // 只有新状态优先级 >= 旧状态优先级时才更新状态
        // 防止 unknown / pending 覆盖已知的 processing 状态
        const newPrio = statusPriority(t.status);
        const oldPrio = statusPriority(prev.status);
        if (newPrio >= oldPrio) {
          intercepted.tasks[t.id] = { ...prev, ...t, _lastSeenAt: now };
        } else {
          // 保留旧状态，但合并其他字段（如prompt）
          intercepted.tasks[t.id] = { ...prev, ...t, status: prev.status, _lastSeenAt: now };
        }
      }
    }
    // 上报给 background（同步活动任务）—— 扩大进行中状态的识别范围
    const runningTasks = getVisibleTasks().filter(t => {
      const s = t.status;
      return s === 'running' || s === 'pending' || s === 'processing' || s === 'in_queue' || s === 'submitted';
    });
    safeSendRuntimeMessage({ type: 'SYNC_ACTIVE_FROM_PAGE', tasks: runningTasks });
  }

  // ============ 主动轮询：在页面上下文中调用即梦API ============
  async function fetchTasksFromApi() {
    // 先用已知有效路径
    const tryPaths = activeApiPath
      ? [activeApiPath, ...KNOWN_TASK_APIS.filter(p => p !== activeApiPath)]
      : KNOWN_TASK_APIS;

    for (const path of tryPaths) {
      try {
        const resp = await fetch(path, {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
          }
        });
        if (!resp.ok) continue;
        const json = await resp.json();
        // 检查是否有任务数据（不报错且有data字段）
        if (json && (json.data || json.list || json.items || json.works)) {
          // 触发interceptor解析（通过让拦截器处理）
          window.postMessage({
            __source: 'jimeng_content',
            type: 'PARSE_RESPONSE',
            url: path,
            data: json,
          }, '*');
          if (!activeApiPath) {
            activeApiPath = path;
            console.log('[即梦监控] 发现有效API路径:', path);
          }
          return json;
        }
      } catch (e) {}
    }
    return null;
  }

  // ============ 响应 background 的消息 ============
  if (isExtensionContextValid()) chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleBgMessage(message).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  });

  async function simulateDomSubmit(params) {
    return new Promise(async (resolve) => {
      try {
        const task = params || {};
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const norm = t => String(t || '').replace(/\s+/g, '').trim();
        const textLike = (a, b) => {
          const x = norm(a);
          const y = norm(b);
          if (!x || !y) return false;
          return x === y || x.includes(y) || y.includes(x);
        };

        const getCandidateDocs = () => {
          const docs = [document];
          for (const frame of Array.from(document.querySelectorAll('iframe'))) {
            try {
              if (frame.contentDocument) docs.push(frame.contentDocument);
            } catch {}
          }
          return docs;
        };

        const pickWorkDoc = () => {
          let best = document;
          let score = -1;
          for (const d of getCandidateDocs()) {
            try {
              const s =
                d.querySelectorAll('textarea, [contenteditable="true"]').length * 3 +
                d.querySelectorAll('.arco-select-view, [role="combobox"], [class*="select-view"]').length * 2 +
                d.querySelectorAll('input[type="file"]').length;
              if (s > score) {
                score = s;
                best = d;
              }
            } catch {}
          }
          return best;
        };

        const workDoc = pickWorkDoc();

        const isVis = (el) => {
          if (!el || !(el instanceof Element)) return false;
          const s = window.getComputedStyle(el);
          const r = el.getBoundingClientRect();
          return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0' && r.width > 0 && r.height > 0;
        };

        const click = async (el) => {
          if (!el || !isVis(el)) return false;
          try {
            el.focus?.();
            const r = el.getBoundingClientRect();
            const cx = r.left + r.width / 2;
            const cy = r.top + r.height / 2;
            const opts = { bubbles: true, cancelable: true, composed: true, view: window, clientX: cx, clientY: cy };
            if (typeof PointerEvent === 'function') {
              el.dispatchEvent(new PointerEvent('pointerdown', opts));
              el.dispatchEvent(new PointerEvent('pointerup', opts));
            }
            el.dispatchEvent(new MouseEvent('mousedown', opts));
            el.dispatchEvent(new MouseEvent('mouseup', opts));
            el.dispatchEvent(new MouseEvent('click', opts));
            el.click?.();
            await sleep(140);
            return true;
          } catch {
            return false;
          }
        };

        const getToolbar = () =>
          workDoc.querySelector('[class*="left-panel"], [class*="sidebar"], [class*="tool"], [class*="toolbar"], [class*="control"], [class*="setting"], [class*="param"]') || workDoc.body;

        const queryAllSafe = (root, selector) => {
          try {
            return Array.from((root || workDoc).querySelectorAll(selector));
          } catch {
            return [];
          }
        };

        const LV_COMBO_SELECTOR = 'div[role="combobox"][class*="lv-select-single"]';
        const COMMON_COMBO_SELECTOR = '.arco-select-view, [class*="select-view"], [role="combobox"], .arco-trigger';

        const findByText = (keys, root) => {
          const ks = (Array.isArray(keys) ? keys : [keys]).filter(Boolean);
          const scope = root || workDoc.body;
          const all = Array.from(scope.querySelectorAll('label, span, div, p, button, li, [role]'));
          return all.find(el => {
            if (!isVis(el)) return false;
            const t = el.innerText || el.textContent || '';
            return ks.some(k => textLike(t, k));
          }) || null;
        };

        const FIELD_LABELS = {
          genMode: ['创作模式', '模式', '生成模式'],
          model: ['模型', 'Model'],
          refMode: ['参考模式', '参考', '参考强度'],
          ratio: ['视频比例', '比例', '画幅'],
          duration: ['时长', '视频时长', '片长']
        };

        const usedControls = new Set();

        const getLikelyComboRow = () => {
          const toolbar = getToolbar();

          // 方案2：父容器特征锁定（你提供的方法）
          const byHasInToolbar = queryAllSafe(toolbar, `.flex:has(> ${LV_COMBO_SELECTOR}) ${LV_COMBO_SELECTOR}`).filter(isVis);
          if (byHasInToolbar.length >= 3) {
            return byHasInToolbar.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
          }

          const byHasInDoc = queryAllSafe(workDoc, `.flex:has(> ${LV_COMBO_SELECTOR}) ${LV_COMBO_SELECTOR}`).filter(isVis);
          if (byHasInDoc.length >= 3) {
            return byHasInDoc.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
          }

          // 方案1：语义+核心类（你提供的方法）
          const lvCombos = queryAllSafe(toolbar, LV_COMBO_SELECTOR).filter(isVis);
          if (lvCombos.length >= 3) {
            return lvCombos.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
          }

          return [];
        };

        const orderedControls = () => {
          const lvRow = getLikelyComboRow();
          if (lvRow.length > 0) return lvRow;
          return queryAllSafe(getToolbar(), COMMON_COMBO_SELECTOR).filter(isVis);
        };

        const findControlByLabel = (labels, fallbackIndex) => {
          const toolbar = getToolbar();
          const labelEl = findByText(labels, toolbar) || findByText(labels, workDoc.body);
          if (labelEl) {
            let p = labelEl;
            for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
              const target = p.querySelector('.arco-select-view, [class*="select-view"], [role="combobox"], .arco-trigger');
              if (target && isVis(target) && !usedControls.has(target)) return target;
            }
          }
          const controls = orderedControls();
          if (controls[fallbackIndex] && !usedControls.has(controls[fallbackIndex])) return controls[fallbackIndex];
          const firstUnused = controls.find(ctrl => !usedControls.has(ctrl));
          return firstUnused || null;
        };

        const getHorizontalFieldControls = () => {
          const controls = orderedControls();
          if (controls.length === 0) return [];

          const allLvCombos = queryAllSafe(workDoc, LV_COMBO_SELECTOR).filter(isVis);
          const baseControls = allLvCombos.length >= 3 ? allLvCombos : controls;

          const withRect = baseControls
            .map(el => ({ el, r: el.getBoundingClientRect() }))
            .filter(item => item.r.width > 6 && item.r.height > 6)
            .sort((a, b) => (a.r.top - b.r.top) || (a.r.left - b.r.left));

          const firstCtrl = findControlByLabel(FIELD_LABELS.genMode, 0) || (withRect[0] && withRect[0].el);
          if (!firstCtrl) return controls;

          const firstRect = firstCtrl.getBoundingClientRect();
          const sameRow = withRect
            .filter(item => Math.abs(item.r.top - firstRect.top) <= 56 && item.r.right >= firstRect.left - 20)
            .sort((a, b) => a.r.left - b.r.left)
            .map(item => item.el);

          const deduped = [];
          let lastX = -99999;
          for (const el of sameRow) {
            const x = el.getBoundingClientRect().left;
            if (Math.abs(x - lastX) > 8) {
              deduped.push(el);
              lastX = x;
            }
          }

          if (deduped.length > 1 && deduped[0] !== firstCtrl) {
            const idx = deduped.indexOf(firstCtrl);
            if (idx >= 0) {
              deduped.splice(idx, 1);
              deduped.unshift(firstCtrl);
            }
          }

          if (deduped.length >= 5) return deduped.slice(0, 5);

          // 次级策略：按 top 分组，选数量最多且最靠近第一栏的一组
          const groups = new Map();
          for (const item of withRect) {
            const key = Math.round(item.r.top / 12) * 12;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(item);
          }
          let best = [];
          for (const [key, arr] of groups.entries()) {
            const sorted = arr.sort((a, b) => a.r.left - b.r.left).map(v => v.el);
            if (sorted.length > best.length) best = sorted;
            if (sorted.length === best.length && Math.abs(key - firstRect.top) < 24) best = sorted;
          }
          if (best.length >= 5) return best.slice(0, 5);

          return deduped.length > 0 ? deduped : baseControls;
        };

        const summarizeControls = (controls) => {
          return (controls || []).map((ctrl, idx) => {
            const r = ctrl.getBoundingClientRect();
            return {
              idx,
              x: Math.round(r.left),
              y: Math.round(r.top),
              w: Math.round(r.width),
              text: (readControlText(ctrl) || '').slice(0, 30),
              className: String(ctrl.className || '').slice(0, 80),
            };
          });
        };

        const readControlText = (ctrl) => {
          if (!ctrl) return '';
          const valueEl = ctrl.querySelector('.arco-select-view-value, [class*="value"], [class*="content"]');
          return norm((valueEl?.innerText || valueEl?.textContent || ctrl.innerText || ctrl.textContent || ''));
        };

        const waitDropdown = async (timeout = 1800) => {
          const end = Date.now() + timeout;
          while (Date.now() < end) {
            const inWork = workDoc.querySelector('.arco-select-dropdown, .arco-trigger-popup, [class*="dropdown"], [class*="option-list"]');
            if (inWork && isVis(inWork)) return inWork;
            const inLv = workDoc.querySelector('.lv-select-dropdown, [class*="lv-select"][class*="dropdown"], [class*="lv-select-options"], [role="listbox"]');
            if (inLv && isVis(inLv)) return inLv;
            const inMain = document.querySelector('.arco-select-dropdown, .arco-trigger-popup, .lv-select-dropdown, [class*="dropdown"], [class*="option-list"], [role="listbox"]');
            if (inMain && isVis(inMain)) return inMain;
            await sleep(80);
          }
          return null;
        };

        const pickOption = async (optionText) => {
          const dd = await waitDropdown(2000);
          const roots = [dd, workDoc.body, document.body].filter(Boolean);
          for (const root of roots) {
            const items = Array.from(root.querySelectorAll('li, [role="option"], .arco-select-option, .lv-select-option, [class*="lv-select-option"], [class*="option-item"], [class*="dropdown-item"]'));
            const item = items.find(el => isVis(el) && textLike(el.innerText || el.textContent || '', optionText));
            if (item) {
              await click(item);
              await sleep(260);
              return true;
            }
          }
          return false;
        };

        const selectField = async (fieldKey, optionText, idx, forcedCtrl) => {
          if (!optionText) return true;
          const labels = FIELD_LABELS[fieldKey] || [fieldKey];
          const ctrl = (forcedCtrl && isVis(forcedCtrl) && !usedControls.has(forcedCtrl))
            ? forcedCtrl
            : (idx === 0 ? findControlByLabel(labels, idx) : null);
          if (!ctrl) return false;
          const current = readControlText(ctrl);
          if (current && textLike(current, optionText)) {
            usedControls.add(ctrl);
            return true;
          }
          await click(ctrl);
          await sleep(180);
          let ok = await pickOption(optionText);
          if (!ok) {
            workDoc.body.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            await sleep(140);
            await click(ctrl);
            await sleep(180);
            ok = await pickOption(optionText);
          }
          if (ok) usedControls.add(ctrl);
          return ok;
        };

        const getPromptInput = () => {
          const ta = workDoc.querySelector('textarea.arco-input, textarea[placeholder*="提示"], textarea[placeholder*="描述"], textarea');
          if (ta && isVis(ta)) return ta;
          const ce = workDoc.querySelector('[contenteditable="true"][role="textbox"], [contenteditable="true"]');
          if (ce && isVis(ce)) return ce;
          return null;
        };

        const fillPromptText = async (text) => {
          if (!text) return true;
          const input = getPromptInput();
          if (!input) return false;
          input.focus?.();
          await sleep(70);

          if (input.tagName === 'TEXTAREA') {
            const prev = input.value || '';
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
            if (setter) setter.call(input, text);
            else input.value = text;

            const tracker = input._valueTracker;
            if (tracker && typeof tracker.setValue === 'function') tracker.setValue(prev);

            if (typeof InputEvent === 'function') {
              input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: text, inputType: 'insertText' }));
            } else {
              input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
            }
            input.dispatchEvent(new Event('change', { bubbles: true }));
            await sleep(120);
            return textLike(input.value || '', text.slice(0, 16));
          }

          input.textContent = text;
          input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          await sleep(120);
          return textLike(input.textContent || '', text.slice(0, 16));
        };

        const uploadImage = async () => {
          if (!task.imageData) return true;
          const inputs = Array.from(workDoc.querySelectorAll('input[type="file"]')).filter(el => !el.accept || el.accept.includes('image'));
          if (inputs.length === 0) return false;
          try {
            const b64 = task.imageData.split(',')[1] || task.imageData;
            const bin = atob(b64);
            const arr = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
            const mime = (task.imageData.match(/data:(.*?);/) || [])[1] || 'image/jpeg';
            const file = new File([arr], task.imageName || 'image.jpg', { type: mime });
            const dt = new DataTransfer();
            dt.items.add(file);
            inputs[0].files = dt.files;
            inputs[0].dispatchEvent(new Event('change', { bubbles: true }));
            inputs[0].dispatchEvent(new Event('input', { bubbles: true }));
            await sleep(1000);
            return true;
          } catch {
            return false;
          }
        };

        const clearAllInputsBeforeSubmit = async () => {
          const promptNodes = Array.from(workDoc.querySelectorAll('textarea, [contenteditable="true"]')).filter(isVis);
          for (const node of promptNodes) {
            try {
              node.focus?.();
              if (node.tagName === 'TEXTAREA') {
                const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
                if (setter) setter.call(node, '');
                else node.value = '';
              } else {
                node.textContent = '';
              }
              node.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
              node.dispatchEvent(new Event('change', { bubbles: true }));
            } catch {}
          }

          const fileInputs = Array.from(workDoc.querySelectorAll('input[type="file"]'));
          for (const input of fileInputs) {
            try {
              const emptyDt = new DataTransfer();
              input.files = emptyDt.files;
            } catch {}
            try { input.value = ''; } catch {}
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          }

          const removeBtns = Array.from(workDoc.querySelectorAll('button, [role="button"], span, div'))
            .filter(el => {
              if (!isVis(el)) return false;
              const t = el.innerText || el.textContent || '';
              return textLike(t, '删除') || textLike(t, '移除') || textLike(t, '清空');
            });
          for (const btn of removeBtns.slice(0, 3)) {
            await click(btn);
            await sleep(80);
          }
        };

        const clickSubmitAtPrompt = async () => {
          const input = getPromptInput();
          const wrap = input ? (input.closest('[class*="prompt"], [class*="input"], [class*="editor"], [class*="textarea"]') || input.parentElement) : workDoc.body;
          const candidates = Array.from((wrap || workDoc.body).querySelectorAll('button, [role="button"], [aria-label]'))
            .filter(el => isVis(el) && !el.disabled);

          const strong = candidates.find(el => {
            const txt = el.innerText || el.textContent || '';
            const ar = el.getAttribute('aria-label') || '';
            const tt = el.getAttribute('title') || '';
            const cls = el.className || '';
            return textLike(txt, '提交') || textLike(txt, '生成') || textLike(ar, '提交') || textLike(ar, '生成') || textLike(tt, '提交') || textLike(tt, '生成') || /send|submit|generate/i.test(cls);
          });
          if (strong && await click(strong)) return true;

          const byPosition = candidates
            .map(el => ({ el, r: el.getBoundingClientRect() }))
            .sort((a, b) => (b.r.bottom - a.r.bottom) || (b.r.right - a.r.right));
          if (byPosition[0] && await click(byPosition[0].el)) return true;

          const globalBtn = workDoc.querySelector('[class*="send"], [class*="submit"], [class*="generate"], button[type="submit"], [aria-label*="提交"], [aria-label*="生成"]');
          if (globalBtn && isVis(globalBtn) && !globalBtn.disabled && await click(globalBtn)) return true;
          return false;
        };

        const waitSubmitConfirmed = async (beforeRunningCount, beforeVisibleCount) => {
          const endAt = Date.now() + 12000;
          let lastFetchAt = 0;
          while (Date.now() < endAt) {
            if (Date.now() - lastFetchAt > 1800) {
              try { await fetchTasksFromApi(); } catch {}
              lastFetchAt = Date.now();
            }

            const runningNow = getRunningVideoTasks().length;
            if (runningNow > beforeRunningCount) {
              return { confirmed: true, signal: 'running-increased' };
            }

            const visibleNow = getVisibleTasks().length;
            if (visibleNow > beforeVisibleCount) {
              return { confirmed: true, signal: 'visible-increased' };
            }

            const input = getPromptInput();
            if (input && task.prompt) {
              if (input.tagName === 'TEXTAREA') {
                const v = norm(input.value || '');
                if (!v) return { confirmed: true, signal: 'prompt-cleared' };
              } else {
                const v = norm(input.textContent || '');
                if (!v) return { confirmed: true, signal: 'prompt-cleared' };
              }
            }

            await sleep(260);
          }
          return { confirmed: false, signal: 'no-confirm-signal' };
        };

        // 1) 先刷新页面内容（软刷新：清空弹层+清空输入）
        try { window.scrollTo(0, 0); } catch {}
        workDoc.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
        await sleep(220);
        const clearBtn = findByText(['清空', '重置', '重新开始', '刷新'], workDoc.body);
        if (clearBtn) await click(clearBtn);
        await clearAllInputsBeforeSubmit();
        await sleep(260);

        const rowControls = getHorizontalFieldControls();
        const rowDebug = summarizeControls(rowControls);
        if (rowControls.length < 5) {
          return resolve({
            error: `控件定位失败：并排下拉仅识别到${rowControls.length}个，期望5个`,
            debug: { rowControls: rowDebug }
          });
        }

        // 2) 创作模式
        const genMode = task.genMode || task.mode || '视频生成';
        const ok1 = await selectField('genMode', genMode, 0, rowControls[0]);
        await sleep(280);

        // 3) 模型
        const model = task.model || task.modelName || '';
        const ok2 = model ? await selectField('model', model, 1, rowControls[1]) : true;
        await sleep(280);

        // 4) 参考模式
        const refMode = task.refMode || '';
        const ok3 = refMode ? await selectField('refMode', refMode, 2, rowControls[2]) : true;
        await sleep(280);

        // 5) 视频比例
        const ratio = task.ratio || '';
        const ok4 = ratio ? await selectField('ratio', ratio, 3, rowControls[3]) : true;
        await sleep(280);

        // 6) 时长
        const duration = task.duration || '';
        const ok5 = duration ? await selectField('duration', duration, 4, rowControls[4]) : true;
        await sleep(280);

        // 7) 填提示词 + 传图片
        const okPromptA = task.prompt ? await fillPromptText(task.prompt) : true;
        await sleep(120);
        const okImage = await uploadImage();
        const okPromptB = task.prompt ? await fillPromptText(task.prompt) : true;
        await sleep(180);

        const beforeRunningCount = getRunningVideoTasks().length;
        const beforeVisibleCount = getVisibleTasks().length;

        // 8) 点击提示词框右下角提交
        let submitted = await clickSubmitAtPrompt();
        if (!submitted) {
          const endAt = Date.now() + 3000;
          while (!submitted && Date.now() < endAt) {
            submitted = await clickSubmitAtPrompt();
            await sleep(140);
          }
        }

        if (!submitted) {
          return resolve({
            error: '未找到提交按钮',
            debug: { ok1, ok2, ok3, ok4, ok5, okPromptA, okImage, okPromptB }
          });
        }

        const submitConfirm = await waitSubmitConfirmed(beforeRunningCount, beforeVisibleCount);
        if (!submitConfirm.confirmed) {
          return resolve({
            error: '点击提交后未观察到任务进入队列',
            debug: { ok1, ok2, ok3, ok4, ok5, okPromptA, okImage, okPromptB, submitConfirm }
          });
        }

        resolve({ ok: true, confirmed: true, signal: submitConfirm.signal, debug: { ok1, ok2, ok3, ok4, ok5, okPromptA, okImage, okPromptB } });
      } catch (e) {
        resolve({ error: 'DOM操作异常: ' + e.message });
      }
    });
  }

  async function handleBgMessage(message) {
    switch (message.type) {

      case 'GET_TASK_LIST': {
        // 先主动拉一次API (带超时保护，防止阻塞)
        const fetchPromise = fetchTasksFromApi();
        const timeoutPromise = new Promise(resolve => setTimeout(resolve, 3000));
        await Promise.race([fetchPromise, timeoutPromise]);
        
        const domTasks = parseTasksFromDOM();
        if (domTasks.length > 0) mergeTaskData(domTasks);
        // 返回当前捕获到的所有任务
        const tasks = getVisibleTasks();
        return {
          allTasks: tasks,
          activeTasksSnapshot: getRunningVideoTasks(),
          apiAvailable: true,
        };
      }

      case 'SUBMIT_TASK': {
        const timeoutPromise = new Promise(resolve => setTimeout(() => resolve({ error: 'DOM模拟点击超时' }), 60000));
        const domPromise = simulateDomSubmit(message.params);
        const domResult = await Promise.race([domPromise, timeoutPromise]);
        
        if (domResult && !domResult.error) {
           return domResult;
        }

        console.log('[即梦监控] DOM模拟点击未生效或超时，降级使用原生API提交:', domResult?.error);

        // 让 interceptor 在页面上下文中提交任务（绕过CORS）
        const reqId = 'req_' + Date.now();
        const result = await new Promise((resolve) => {
          if (!window._jimengSubmitResolvers) window._jimengSubmitResolvers = {};
          window._jimengSubmitResolvers[reqId] = resolve;
          setTimeout(() => {
            if (window._jimengSubmitResolvers[reqId]) {
              resolve({ error: 'timeout' });
              delete window._jimengSubmitResolvers[reqId];
            }
          }, 45000);
          window.postMessage({
            __source: 'jimeng_content',
            type: 'SUBMIT_TASK',
            params: message.params,
            reqId,
          }, '*');
        });
        if (result && result.error) {
          return {
            error: `DOM失败: ${domResult?.error || 'unknown'}; API失败: ${result.error}`,
            domError: domResult?.error || 'unknown',
            apiError: result.error,
            debug: domResult?.debug || null,
          };
        }
        return result;
      }

      case 'GET_AUTH': {
        return intercepted;
      }

      default:
        return { error: 'unknown' };
    }
  }

  // ============ DOM 观察：解析页面上的任务卡片 ============
  function parseTasksFromDOM() {
    const tasks = [];

    // 即梦视频生成页面的实际DOM结构（根据 /ai-tool/generate 页面）
    const selectors = [
      '[data-task-id]',
      '[data-id]',
      '[class*="task-item"]',
      '[class*="generate-item"]',
      '[class*="video-task"]',
      '[class*="creation-item"]',
      '[class*="history-item"]',
      '[class*="record-item"]',
      '[class*="work-item"]',
      '[class*="draft-item"]',
      '[class*="card-wrap"]',
      '[class*="GenerateItem"]',
      '[class*="TaskCard"]',
      '[class*="VideoCard"]',
    ];

    const seen = new Set();
    for (const sel of selectors) {
      let els;
      try { els = document.querySelectorAll(sel); } catch { continue; }
      for (const el of els) {
        const taskId =
          el.dataset.taskId ||
          el.dataset.id ||
          el.dataset.generateId ||
          el.getAttribute('data-task-id') ||
          el.getAttribute('data-id') ||
          el.getAttribute('data-generate-id');
        if (!taskId || seen.has(taskId)) continue;
        seen.add(taskId);

        // 推测状态（中文文本 + CSS类名）
        let status = 'unknown';
        const text = el.textContent || '';
        const html = el.innerHTML || '';

        if (
          el.querySelector('[class*="loading"],[class*="progress"],[class*="generating"],[class*="spinning"],[class*="pending"],[class*="running"]') ||
          text.includes('生成中') || text.includes('处理中') || text.includes('排队') ||
          text.includes('等待') || text.includes('提交中') || html.includes('loading')
        ) {
          status = 'processing';
        } else if (
          el.querySelector('[class*="fail"],[class*="error"],[class*="failed"]') ||
          text.includes('失败') || text.includes('错误') || text.includes('超时')
        ) {
          status = 'failed';
        } else if (
          el.querySelector('[class*="success"],[class*="done"],[class*="complete"],[class*="finish"]') ||
          text.includes('完成') || text.includes('成功') || text.includes('已生成')
        ) {
          status = 'success';
        }

        const kind = isDomVideoCard(el, text, html) ? 'video' : 'unknown';

        if (status !== 'unknown') {
          tasks.push({ id: taskId, status, source: 'dom', kind });
        }
      }
    }

    return tasks;
  }

  // 定期扫描DOM + 主动拉API
  let pollCount = 0;
  setInterval(async () => {
    const domTasks = parseTasksFromDOM();
    if (domTasks.length > 0) mergeTaskData(domTasks);

    // 每隔3次（约9秒）主动调一次API
    pollCount++;
    if (pollCount % 3 === 0) {
      await fetchTasksFromApi();
    }
  }, 3000);

  // ============ 监听即梦的自定义事件（如果有）============
  document.addEventListener('jimeng:task:update', (e) => {
    if (e.detail) mergeTaskData([e.detail]);
  });

  console.log('[即梦监控] Content script 已注入');
})();
